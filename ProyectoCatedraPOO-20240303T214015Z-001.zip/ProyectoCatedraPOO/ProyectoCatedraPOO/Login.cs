﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using CapaEntidad;

namespace ProyectoCatedraPOO
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btniniciodesesion_Click(object sender, EventArgs e)
        {
            List<Usuario> TEST = new CN_Usuario().listar();


            Usuario ousuario = new CN_Usuario().listar().Where(u => u.documento==txtUsuario.Text && u.Clave== txtPass.Text).FirstOrDefault();

            if (ousuario != null)
            {

                Form1 form1 = new Form1(ousuario);
                form1.Show();
                this.Hide();

                form1.FormClosing += frm_closing;
            }
            else
            {
                MessageBox.Show("No se encuentra el usuario");
            }
        }
        private void frm_closing(object sender, FormClosingEventArgs e)
        {
            txtUsuario.Text = "";
            txtPass.Text = "";
            this.Show();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
